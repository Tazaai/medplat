import React from "react";

export default function App() {
  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>✅ MedPlat Frontend</h1>
      <p>Connected to Cloud Run backend.</p>
    </div>
  );
}
